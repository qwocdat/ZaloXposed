package io.github.electroheavenvn.zaloxposed.utilities;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import io.github.electroheavenvn.zaloxposed.MorpheConstants;

public final class Config
{
    private Config() { }

    public interface OnConfigChangedListener
    {
        void onConfigChanged(String key, Object oldValue, Object newValue);
    }

    private static final List<OnConfigChangedListener> listeners = new ArrayList<>();

    private static File file = null;

    private static JSONObject config = new JSONObject();

    public static File getConfigFile()
    {
        if (file == null)
            file = new File(Utils.GetZaloXposedDir(), "config.json");
        return file;
    }

    public static void addOnConfigChangedListener(OnConfigChangedListener listener)
    {
        listeners.add(listener);
    }

    public static void removeOnConfigChangedListener(OnConfigChangedListener listener)
    {
        listeners.remove(listener);
    }

    private static void notifyConfigChanged(String key, Object oldValue, Object newValue)
    {
        for (OnConfigChangedListener listener : listeners)
        {
            try
            {
                listener.onConfigChanged(key, oldValue, newValue);
            }
            catch (Exception e) { Logger.e(e); }
        }
    }

    public static void Load()
    {
        try
        {
            File configFile = getConfigFile();
            if (!configFile.exists())
            {
                File parent = configFile.getParentFile();
                if (parent != null && !parent.exists())
                    parent.mkdirs();
                FileWriter fw = new FileWriter(configFile);
                fw.write("{}");
                fw.close();
            }
            StringBuilder content = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader(configFile));
            String line;
            while ((line = reader.readLine()) != null)
                content.append(line).append("\n");
            reader.close();
            config = new JSONObject(content.toString());
        }
        catch (Exception e) { Logger.e(e); }
    }

    public static void Reset()
    {
        config = new JSONObject();
        save();
    }

    private static void save()
    {
        try
        {
            File configFile = getConfigFile();
            File parent = configFile.getParentFile();
            if (parent != null && !parent.exists())
                parent.mkdirs();
            FileWriter fw = new FileWriter(configFile);
            fw.write(config.toString());
            fw.close();
        }
        catch (Exception e) { Logger.e(e); }
    }

    public static String getConfigJsonString()
    {
        try
        {
            return config.toString(4);
        }
        catch (Exception e)
        {
            return config.toString();
        }
    }

    public static boolean exportToFile(File targetFile)
    {
        try
        {
            File parent = targetFile.getParentFile();
            if (parent != null && !parent.exists())
                parent.mkdirs();
            try (FileWriter fw = new FileWriter(targetFile))
            {
                fw.write(config.toString(4));
            }
            return true;
        }
        catch (Exception e)
        {
            Logger.e(e);
            return false;
        }
    }

    public static boolean importFromFile(File sourceFile)
    {
        try
        {
            if (!sourceFile.exists() || !sourceFile.isFile())
                return false;
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(sourceFile)))
            {
                String line;
                while ((line = reader.readLine()) != null)
                    content.append(line).append("\n");
            }
            config = new JSONObject(content.toString());
            save();
            return true;
        }
        catch (Exception e)
        {
            Logger.e(e);
            return false;
        }
    }

    public static boolean exportToStream(java.io.OutputStream outputStream)
    {
        try (outputStream)
        {
            outputStream.write(config.toString(4).getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
            return true;
        }
        catch (Exception e)
        {
            Logger.e(e);
            return false;
        }
    }

    public static boolean importFromStream(java.io.InputStream inputStream)
    {
        try (inputStream; BufferedReader reader = new BufferedReader(new java.io.InputStreamReader(inputStream, StandardCharsets.UTF_8)))
        {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null)
                content.append(line).append("\n");
            config = new JSONObject(content.toString());
            save();
            return true;
        }
        catch (Exception e)
        {
            Logger.e(e);
            return false;
        }
    }

    public static Object get(String key, Object defaultValue)
    {
        try
        {
            if (!config.has(key))
                config.putOpt(key, defaultValue);
            if (defaultValue instanceof Long)
                return config.getLong(key);
            return config.get(key);
        }
        catch (Exception e) { Logger.e(e); }
        return defaultValue;
    }

    public static void set(String key, Object value)
    {
        try
        {
            Object oldValue = config.opt(key);
            config.putOpt(key, value);
            save();
            notifyConfigChanged(key, oldValue, value);
        }
        catch (Exception e) { Logger.e(e); }
    }

    public static final String KEY_ENABLE_BACKGROUND = "enable_bg";
    public static boolean getEnableBackground() { return (boolean)get(KEY_ENABLE_BACKGROUND, true); }
    public static void setEnableBackground(boolean value) { set(KEY_ENABLE_BACKGROUND, value); }

    public static final String KEY_ENABLE_CUSTOM_RINGTONE = "enable_custom_ringtone";
    public static boolean getEnableCustomRingtone() { return (boolean)get(KEY_ENABLE_CUSTOM_RINGTONE, true); }
    public static void setEnableCustomRingtone(boolean value) { set(KEY_ENABLE_CUSTOM_RINGTONE, value); }

    public static final String KEY_ENABLE_EXTENDED_GRID_MENU = "enable_extended_grid_menu";
    public static boolean getEnableExtendedGridMenu() { return (boolean)get(KEY_ENABLE_EXTENDED_GRID_MENU, false); }
    public static void setEnableExtendedGridMenu(boolean value) { set(KEY_ENABLE_EXTENDED_GRID_MENU, value); }

    public static final String KEY_ENABLE_EXTENDED_GROUP_RIGHT_MENU = "enable_extended_group_right_menu";
    public static boolean getEnableExtendedGroupRightMenu() { return (boolean)get(KEY_ENABLE_EXTENDED_GROUP_RIGHT_MENU, false); }
    public static void setEnableExtendedGroupRightMenu(boolean value) { set(KEY_ENABLE_EXTENDED_GROUP_RIGHT_MENU, value); }

    public static final String KEY_ENABLE_CHAT_HEAD = "enable_chat_head";
    public static boolean getEnableChatHead() { return (boolean)get(KEY_ENABLE_CHAT_HEAD, false); }
    public static void setEnableChatHead(boolean value) { set(KEY_ENABLE_CHAT_HEAD, value); }

    public static final String KEY_UNLOCK_ZCLOUD = "unlock_zcloud";
    public static boolean getUnlockZCloud() { return (boolean)get(KEY_UNLOCK_ZCLOUD, false); }
    public static void setUnlockZCloud(boolean value) { set(KEY_UNLOCK_ZCLOUD, value); }

    public static final String KEY_UNLOCK_ZSTYLE = "unlock_zstyle";
    public static boolean getUnlockZStyle() { return (boolean)get(KEY_UNLOCK_ZSTYLE, false); }
    public static void setUnlockZStyle(boolean value) { set(KEY_UNLOCK_ZSTYLE, value); }

    public static final String KEY_ENABLE_TTL_OVERRIDE = "enable_msg_ttl_override";
    public static boolean getEnableTTLOverride() { return (boolean)get(KEY_ENABLE_TTL_OVERRIDE, false); }
    public static void setEnableTTLOverride(boolean value) { set(KEY_ENABLE_TTL_OVERRIDE, value); }

    public static final String KEY_MSG_TTL = "msg_ttl_value";
    public static long getTTL() { return (long)get(KEY_MSG_TTL, 0L); }
    public static void setTTL(long value) { set(KEY_MSG_TTL, value); }

    public static final String KEY_ENABLE_FAKE_GROUP_ROLE = "enable_fake_group_role";
    public static boolean getEnableFakeGroupRole() { return (boolean)get(KEY_ENABLE_FAKE_GROUP_ROLE, false); }
    public static void setEnableFakeGroupRole(boolean value) { set(KEY_ENABLE_FAKE_GROUP_ROLE, value); }

    public static final String KEY_FAKE_GROUP_ROLE_LEVEL = "fake_group_role_level";
    public static int getFakeGroupRoleLevel() { return (int)get(KEY_FAKE_GROUP_ROLE_LEVEL, 0); }
    public static void setFakeGroupRoleLevel(int value) { set(KEY_FAKE_GROUP_ROLE_LEVEL, value); }

    public static final String KEY_ENABLE_SHARE_HIDDEN_STICKER_PACK = "enable_share_hidden_sticker_pack";
    public static boolean getEnableShareHiddenStickerPack() { return (boolean)get(KEY_ENABLE_SHARE_HIDDEN_STICKER_PACK, false); }
    public static void setEnableShareHiddenStickerPack(boolean value) { set(KEY_ENABLE_SHARE_HIDDEN_STICKER_PACK, value); }

    public static final String KEY_ENABLE_EXTENDED_GROUP_SETTING_MENU = "enable_extended_group_setting_menu";
    public static boolean getEnableExtendedGroupSettingMenu() { return (boolean)get(KEY_ENABLE_EXTENDED_GROUP_SETTING_MENU, false); }
    public static void setEnableExtendedGroupSettingMenu(boolean value) { set(KEY_ENABLE_EXTENDED_GROUP_SETTING_MENU, value); }

    public static final String KEY_HIDE_MEDIA_BOX = "ads_hide_media_box";
    public static boolean getHideMediaBox() { return (boolean)get(KEY_HIDE_MEDIA_BOX, false); }
    public static void setHideMediaBox(boolean value) { set(KEY_HIDE_MEDIA_BOX, value); }

    public static final String KEY_HIDE_BIZ_BOX = "ads_hide_business_box";
    public static boolean getHideBizBox() { return (boolean)get(KEY_HIDE_BIZ_BOX, false); }
    public static void setHideBizBox(boolean value) { set(KEY_HIDE_BIZ_BOX, value); }

    public static final String KEY_ENABLE_CUSTOMIZE_BOTTOM_ROW = "enable_customize_bottom_row";
    public static boolean getEnableCustomizeBottomRow() { return (boolean)get(KEY_ENABLE_CUSTOMIZE_BOTTOM_ROW, false); }
    public static void setEnableCustomizeBottomRow(boolean value) { set(KEY_ENABLE_CUSTOMIZE_BOTTOM_ROW, value); }

    public static final String KEY_HIDE_DISCOVERY_TAB = "ads_hide_discovery_tab";
    public static boolean getHideDiscoveryTab() { return (boolean)get(KEY_HIDE_DISCOVERY_TAB, false); }
    public static void setHideDiscoveryTab(boolean value) { set(KEY_HIDE_DISCOVERY_TAB, value); }

    public static final String KEY_HIDE_NEWS_FEED_TAB = "ads_hide_news_feed_tab";
    public static boolean getHideNewsFeedTab() { return (boolean)get(KEY_HIDE_NEWS_FEED_TAB, false); }
    public static void setHideNewsFeedTab(boolean value) { set(KEY_HIDE_NEWS_FEED_TAB, value); }

    public static final String KEY_SHOW_MORE_TAB = "ads_show_more_tab";
    public static boolean getShowMoreTab() { return (boolean)get(KEY_SHOW_MORE_TAB, false); }
    public static void setShowMoreTab(boolean value) { set(KEY_SHOW_MORE_TAB, value); }

    public static final String KEY_SHOW_GROUPS_TAB = "ads_show_groups_tab";
    public static boolean getShowGroupsTab() { return (boolean)get(KEY_SHOW_GROUPS_TAB, false); }
    public static void setShowGroupsTab(boolean value) { set(KEY_SHOW_GROUPS_TAB, value); }

    public static final String KEY_ENABLE_LIQUID_GLASS_TABBAR = "enable_liquid_glass_tabbar";
    public static boolean getEnableLiquidGlassTabBar() { return (boolean)get(KEY_ENABLE_LIQUID_GLASS_TABBAR, false); }
    public static void setEnableLiquidGlassTabBar(boolean value) { set(KEY_ENABLE_LIQUID_GLASS_TABBAR, value); }

    public static final String KEY_LIQUID_GLASS_THEME = "liquid_glass_tabbar_theme";
    public static int getLiquidGlassTheme() { return (int)get(KEY_LIQUID_GLASS_THEME, 0); }
    public static void setLiquidGlassTheme(int value) { set(KEY_LIQUID_GLASS_THEME, value); }

    public static final String KEY_HIDE_WELCOME_DIALOG = "hide_welcome_dialog";
    public static boolean getHideWelcomeDialog() { return (boolean)get(KEY_HIDE_WELCOME_DIALOG, false); }
    public static void setHideWelcomeDialog(boolean value) { set(KEY_HIDE_WELCOME_DIALOG, value); }

    public static final String KEY_ENABLE_ANTI_RECALL = "enable_anti_recall";
    public static boolean getEnableAntiRecall() { return (boolean)get(KEY_ENABLE_ANTI_RECALL, false); }
    public static void setEnableAntiRecall(boolean value) { set(KEY_ENABLE_ANTI_RECALL, value); }

    public static final String KEY_ENABLE_ANTI_DELETE = "enable_anti_delete";
    public static boolean getEnableAntiDelete() { return (boolean)get(KEY_ENABLE_ANTI_DELETE, false); }
    public static void setEnableAntiDelete(boolean value) { set(KEY_ENABLE_ANTI_DELETE, value); }

    public static final String KEY_ANTI_RECALL_INCLUDE_ME = "anti_recall_include_me";
    public static boolean getAntiRecallIncludeMe() { return (boolean)get(KEY_ANTI_RECALL_INCLUDE_ME, false); }
    public static void setAntiRecallIncludeMe(boolean value) { set(KEY_ANTI_RECALL_INCLUDE_ME, value); }

    public static final String KEY_ANTI_DELETE_INCLUDE_MY_DELETION = "anti_delete_include_my_deletion";
    public static boolean getAntiDeleteIncludeMyDeletion() { return (boolean)get(KEY_ANTI_DELETE_INCLUDE_MY_DELETION, false); }
    public static void setAntiDeleteIncludeMyDeletion(boolean value) { set(KEY_ANTI_DELETE_INCLUDE_MY_DELETION, value); }

    public static final String KEY_HIDE_Z_INSTANT_ADS = "ads_hide_z_instant";
    public static boolean getHideZInstantAds() { return (boolean)get(KEY_HIDE_Z_INSTANT_ADS, false); }
    public static void setHideZInstantAds(boolean value) { set(KEY_HIDE_Z_INSTANT_ADS, value); }

    public static final String KEY_HIDE_FEED_ITEM_Z_INSTANT_ADS = "ads_hide_feed_item_z_instant";
    public static boolean getHideFeedItemZInstantAds() { return (boolean)get(KEY_HIDE_FEED_ITEM_Z_INSTANT_ADS, false); }
    public static void setHideFeedItemZInstantAds(boolean value) { set(KEY_HIDE_FEED_ITEM_Z_INSTANT_ADS, value); }

    public static final String KEY_BLOCK_ADS_ENDPOINTS = "block_ads_endpoints";
    public static boolean getBlockAdsEndpoints() { return (boolean)get(KEY_BLOCK_ADS_ENDPOINTS, false); }
    public static void setBlockAdsEndpoints(boolean value) { set(KEY_BLOCK_ADS_ENDPOINTS, value); }

    public static final String KEY_DISABLE_FIREBASE_LOGGING = "logging_disable_firebase";
    public static boolean getDisableFirebaseLogging() { return (boolean)get(KEY_DISABLE_FIREBASE_LOGGING, true); }
    public static void setDisableFirebaseLogging(boolean value) { set(KEY_DISABLE_FIREBASE_LOGGING, value); }

    public static final String KEY_DISABLE_ZALO_TRACKING = "logging_disable_zalo_tracking";
    public static boolean getDisableZaloTracking() { return (boolean)get(KEY_DISABLE_ZALO_TRACKING, true); }
    public static void setDisableZaloTracking(boolean value) { set(KEY_DISABLE_ZALO_TRACKING, value); }

    public static final String KEY_BLOCK_ZALO_QOS = "logging_block_zalo_qos";
    public static boolean getBlockQoSEndpoints() { return (boolean)get(KEY_BLOCK_ZALO_QOS, true); }
    public static void setBlockQoSEndpoints(boolean value) { set(KEY_BLOCK_ZALO_QOS, value); }

    public static final String KEY_ENABLE_SILENT_TYPING = "enable_silent_typing";
    public static boolean getEnableSilentTyping() { return (boolean)get(KEY_ENABLE_SILENT_TYPING, false); }
    public static void setEnableSilentTyping(boolean value) { set(KEY_ENABLE_SILENT_TYPING, value); }

    public static final String KEY_BLOCK_SEND_SEEN = "block_send_seen";
    public static boolean getBlockSendSeen() { return (boolean)get(KEY_BLOCK_SEND_SEEN, false); }
    public static void setBlockSendSeen(boolean value) { set(KEY_BLOCK_SEND_SEEN, value); }

    public static final String KEY_RESTORE_PROFILE_MUSIC = "restore_profile_music";
    public static boolean getRestoreProfileMusic() { return (boolean)get(KEY_RESTORE_PROFILE_MUSIC, false); }
    public static void setRestoreProfileMusic(boolean value) { set(KEY_RESTORE_PROFILE_MUSIC, value); }

    public static final String KEY_RESTORE_GOOGLE_DRIVE_BACKUP = "restore_google_drive_backup";
    public static boolean getRestoreGoogleDriveBackup() { return (boolean)get(KEY_RESTORE_GOOGLE_DRIVE_BACKUP, false); }
    public static void setRestoreGoogleDriveBackup(boolean value) { set(KEY_RESTORE_GOOGLE_DRIVE_BACKUP, value); }

    public static final String KEY_HIDE_FULLSCREEN_EFFECTS = "hide_fullscreen_effects";
    public static boolean getHideFullscreenEffects() { return (boolean)get(KEY_HIDE_FULLSCREEN_EFFECTS, false); }
    public static void setHideFullscreenEffects(boolean value) { set(KEY_HIDE_FULLSCREEN_EFFECTS, value); }

    public static final String KEY_DEFAULT_ORIGINAL_QUALITY = "default_original_quality";
    public static boolean getDefaultOriginalQuality() { return (boolean)get(KEY_DEFAULT_ORIGINAL_QUALITY, false); }
    public static void setDefaultOriginalQuality(boolean value) { set(KEY_DEFAULT_ORIGINAL_QUALITY, value); }

    public static final String KEY_DEFAULT_ORIGINAL_QUALITY_PASTED = "default_original_quality_pasted";
    public static boolean getDefaultOriginalQualityPasted() { return (boolean)get(KEY_DEFAULT_ORIGINAL_QUALITY_PASTED, false); }
    public static void setDefaultOriginalQualityPasted(boolean value) { set(KEY_DEFAULT_ORIGINAL_QUALITY_PASTED, value); }

    public static final String KEY_DEFAULT_ORIGINAL_QUALITY_SHARE = "default_original_quality_share";
    public static boolean getDefaultOriginalQualityShare() { return (boolean)get(KEY_DEFAULT_ORIGINAL_QUALITY_SHARE, false); }
    public static void setDefaultOriginalQualityShare(boolean value) { set(KEY_DEFAULT_ORIGINAL_QUALITY_SHARE, value); }

    public static final String KEY_DEFAULT_ORIGINAL_QUALITY_CAMERA = "default_original_quality_camera";
    public static boolean getDefaultOriginalQualityCamera() { return (boolean)get(KEY_DEFAULT_ORIGINAL_QUALITY_CAMERA, false); }
    public static void setDefaultOriginalQualityCamera(boolean value) { set(KEY_DEFAULT_ORIGINAL_QUALITY_CAMERA, value); }
    
    public static final String KEY_ENABLE_MICROG = "enable_microg_root";
    public static boolean getEnableMicroG() { return (boolean)get(KEY_ENABLE_MICROG, MorpheConstants.isPatchedByMorphe()); }
    public static void setEnableMicroG(boolean value) { set(KEY_ENABLE_MICROG, value); }

    public static final String KEY_SELECTED_MICROG_VARIANT_ID = "microg_selected_variant_id";
    public static String getSelectedMicroGVariantID() { return (String)get(KEY_SELECTED_MICROG_VARIANT_ID, ""); }
    public static void setSelectedMicroGVariantID(String value) { set(KEY_SELECTED_MICROG_VARIANT_ID, value); }
}