package io.github.electroheavenvn.zaloxposed.hooks.permanent;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;

import org.json.JSONObject;
import org.luckypray.dexkit.query.FindClass;
import org.luckypray.dexkit.query.FindMethod;
import org.luckypray.dexkit.query.enums.StringMatchType;
import org.luckypray.dexkit.query.matchers.ClassMatcher;
import org.luckypray.dexkit.query.matchers.MethodMatcher;
import org.luckypray.dexkit.result.MethodData;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import io.github.electroheavenvn.zaloxposed.hooks.BaseHook;
import io.github.electroheavenvn.zaloxposed.utilities.DexKitCache;
import io.github.electroheavenvn.zaloxposed.utilities.Logger;

public class AntiRecallDeleteChatRowHook extends BaseHook
{
    List<Field> msgFields = new ArrayList<>();
    Field msgTypeField = null;
    Field quoteField = null;
    Field quoteDisplayNameField = null;
    Field quoteAttrField = null;

    @Override
    public void installHooks() throws Throwable
    {
        Class<?> msgClass = DexKitCache.GetClass("AntiRecallDeleteChatRow_MsgClass", () -> bridge.findClass(FindClass.create()
            .matcher(ClassMatcher.create()
                .addUsingString("gallery_save_video_detail", StringMatchType.Equals)
                .addUsingString("video_download", StringMatchType.Equals)
                .addUsingString("recommened.link", StringMatchType.Equals)
                .addUsingString("senderName", StringMatchType.Equals)
                .addUsingString("platformType", StringMatchType.Equals)
                .addUsingString("recommened.user", StringMatchType.Equals)
                .addUsingString("l.a.header.only", StringMatchType.Equals)
                .addUsingString("l.a.header.full", StringMatchType.Equals)
                .addUsingString("description", StringMatchType.Equals)
                .addUsingString("recommened.vip", StringMatchType.Equals)
                .addUsingString("globalMsgId", StringMatchType.Equals)
                .addUsingString("mentions", StringMatchType.Equals)
                .addUsingString("reference", StringMatchType.Equals)
            )), classLoader);
        if (msgClass == null)
            return;
        Class<?> chatRow = Class.forName("com.zing.zalo.ui.chat.chatrow.ChatRow", false, classLoader);
        for (Field field : chatRow.getDeclaredFields())
        {
            if (!field.getType().equals(msgClass))
                continue;
            field.setAccessible(true);
            msgFields.add(field);
        }
        if (msgFields.isEmpty())
        {
            Logger.e("Target field not found");
            return;
        }
        msgTypeField = DexKitCache.GetFieldRaw("AntiRecallDeleteChatRow_MsgClass_MsgType", classLoader);
        if (msgTypeField == null)
        {
            List<MethodData> methodsData = bridge.findMethod(FindMethod.create()
                .matcher(MethodMatcher.create()
                    .declaredClass(msgClass)
                    .modifiers(Modifier.PUBLIC | Modifier.FINAL)
                    .returnType("boolean")
                    .paramCount(0)
                    .addUsingNumber(36)
                    //261101901 has another method with larger body
                    .not(MethodMatcher.create()
                        .addUsingString("recommened.calltime", StringMatchType.Equals)
                        .addUsingString("recommened.misscall", StringMatchType.Equals)
                        .usingNumbers(24, 26, 33, 34))
                ));
            if (methodsData.isEmpty())
            {
                Logger.e("Target method not found");
                return;
            }
            if (methodsData.size() > 1)
                Logger.w("Multiple target methods found");
            msgTypeField = methodsData.get(0).getUsingFields().get(0).getField().getFieldInstance(classLoader);
            msgTypeField.setAccessible(true);
            DexKitCache.SetFieldRaw("AntiRecallDeleteChatRow_MsgClass_MsgType", msgTypeField);
        }
        Method drawMethod = DexKitCache.GetMethod("AntiRecallDeleteChatRow_ChatRow_DrawMsgBubble", () -> bridge.findMethod(FindMethod.create()
            .matcher(MethodMatcher.create()
                .declaredClass(chatRow)
                .modifiers(Modifier.PUBLIC)
                .returnType("void")
                .paramCount(5)
                .paramTypes("android.graphics.Canvas", "int", "int", "int", "int")
            )), classLoader);
        if (drawMethod == null)
            return;
        doHook(drawMethod, chain ->
        {
            Object thisObj = chain.getThisObject();
            Object msg = null;
            for (Field f : msgFields)
            {
                msg = f.get(thisObj);
                if (msg != null)
                    break;
            }
            if (msg == null)
                return chain.proceed();
            if (msgTypeField.get(msg) != Integer.valueOf(0))
                return chain.proceed();
            String msgStr = msg.toString();
            // toString limited msg content to ~18-20 chars
            boolean isRecall = msgStr.startsWith("ChatContent{msg='Message recalled', ") || msgStr.matches("ChatContent\\{msg='[0-9]+ messages reca.*?', .*");
            boolean isDelete = msgStr.startsWith("ChatContent{msg='Message deleted', ") || msgStr.matches("ChatContent\\{msg='[0-9]+ messages dele.*?', .*");
            if (!isRecall && !isDelete)
                return chain.proceed();
            Object quote = null;
            if (quoteField == null)
            {
                for (Field f : msg.getClass().getFields())  // public fields
                {
                    Class<?> type = f.getType();
                    if (type.isPrimitive() || String.class.equals(type))
                        continue;
                    Object value = f.get(msg);
                    if (value == null)
                        continue;
                    String valueStr = value.toString();
                    if (!valueStr.startsWith("replySenderUid="))
                        continue;
                    if (!valueStr.contains("replySenderGlobalUid="))
                        continue;
                    quoteField = f;
                    quote = value;
                    break;
                }
            }
            else
            {
                quote = quoteField.get(msg);
            }
            if (quote == null)
                return chain.proceed();
            if (quoteDisplayNameField == null || quoteAttrField == null)
            {
                int count = 0;
                for (Field f : quote.getClass().getFields())  // public fields
                {
                    Class<?> type = f.getType();
                    if (type.isPrimitive() || !String.class.equals(type))
                        continue;
                    String value = (String) f.get(quote);
                    if (value == null)
                        continue;
                    if (value.equals("ZaloXposed by DigitalXiao/Quocdat") || value.equals("ZaloxPosed X DigitalXiao by DigitalXiao/Quocdat") || value.equals("ZaloMorphe by DigitalXiao/Quocdat") || value.equals("ZaloXposed by ElectroHeavenVN") || value.equals("ZaloMorphe by ElectroHeavenVN"))
                    {
                        quoteDisplayNameField = f;
                        count++;
                        continue;
                    } 
                    if (value.endsWith(",\"generatedBy\":\"AntiRecallDeleteHook\"}"))
                    {
                        try
                        {
                            JSONObject obj = new JSONObject(value);
                            quoteAttrField = f;
                            count++;
                        }
                        catch (Exception ignored) { }
                    }
                }
                if (count != 2)
                    return chain.proceed();
            }
            else
            {
                Object quoteDisplayName = quoteDisplayNameField.get(quote);
                if (!"ZaloXposed by DigitalXiao/Quocdat".equals(quoteDisplayName) && !"ZaloxPosed X DigitalXiao by DigitalXiao/Quocdat".equals(quoteDisplayName) && !"ZaloMorphe by DigitalXiao/Quocdat".equals(quoteDisplayName) && !"ZaloXposed by ElectroHeavenVN".equals(quoteDisplayName) && !"ZaloMorphe by ElectroHeavenVN".equals(quoteDisplayName))
                    return chain.proceed();
                Object attr = quoteAttrField.get(quote);
                if (attr == null)
                    return chain.proceed();
                if (!attr.toString().endsWith(",\"generatedBy\":\"AntiRecallDeleteHook\"}"))
                    return chain.proceed();
            }
            Canvas canvas = (Canvas)chain.getArg(0);
            int left = (int)chain.getArg(1);
            int top = (int)chain.getArg(2);
            int right = (int)chain.getArg(3);
            int bottom = (int)chain.getArg(4);
            RectF rect = new RectF(left, top, right, bottom);
            int w = right - left;
            int h = bottom - top;
            Bitmap bmp = Bitmap.createBitmap(Math.max(w, 1), Math.max(h, 1), Bitmap.Config.ARGB_8888);
            Canvas fakeCanvas = new Canvas(bmp);
            fakeCanvas.translate(-left, -top);
            Object result = chain.proceed(new Object[]{fakeCanvas, left, top, right, bottom});
            int sampleColor = bmp.getPixel(w / 4, h / 4);
            bmp.recycle();
            double lum = (0.299 * Color.red(sampleColor) + 0.587 * Color.green(sampleColor) + 0.114 * Color.blue(sampleColor)) / 255.0;
            boolean darkTheme = lum < 0.5;
            Paint fill = new Paint();
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(isRecall ? (darkTheme ? 0xB0403800 : 0xDDFFFFDD) : (darkTheme ? 0xB0400000 : 0xDDFFDDDD));
            fill.setAntiAlias(true);
            canvas.drawRoundRect(rect, 24f, 24f, fill);
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(4f);
            paint.setColor(isRecall ? 0xFFFBC02D : 0xFFE53935);
            paint.setAntiAlias(true);
            paint.setPathEffect(new DashPathEffect(new float[]{20f, 12f}, 0f));
            canvas.drawRoundRect(rect, 24f, 24f, paint);
            return result;
        });
    }
}