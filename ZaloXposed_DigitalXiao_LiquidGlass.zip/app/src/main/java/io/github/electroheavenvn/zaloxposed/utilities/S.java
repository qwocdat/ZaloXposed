package io.github.electroheavenvn.zaloxposed.utilities;

import android.text.TextUtils;

import java.util.HashMap;
import java.util.Map;

public final class S
{
    private S() { }

    private static final Map<String, String[]> trans = new HashMap<>();

    static
    {
        // Master menu
        trans.put("backgroundCategoryTitle", new String[] { "Background", "Hình nền" });
        trans.put("backgroundCategoryDesc", new String[] { "Customize background images", "Tuỳ chỉnh ảnh nền" });
        trans.put("callRingtoneCategoryTitle", new String[] { "Call ringtone", "Nhạc chuông cuộc gọi" });
        trans.put("callRingtoneCategoryDesc", new String[] { "Customize the incoming-call ringtone", "Tuỳ chỉnh nhạc chuông cuộc gọi đến" });
        trans.put("msgAndConverCategoryTitle", new String[] { "Messages & Conversations", "Tin nhắn & Trò chuyện" });
        trans.put("msgAndConverCategoryDesc", new String[] { "Customize message appearance and behavior", "Tùy chỉnh hiển thị và hành vi tin nhắn" });
        trans.put("privacyCategoryTitle", new String[] { "Privacy", "Quyền riêng tư" });
        trans.put("privacyCategoryDesc", new String[] { "Control activity status and messages", "Kiểm soát trạng thái hoạt động và tin nhắn" });
        trans.put("adsAndTrackingCategoryTitle", new String[] { "Ads & tracking", "Quảng cáo & theo dõi" });
        trans.put("adsAndTrackingCategoryDesc", new String[] { "Hide ads and limit tracking", "Ẩn quảng cáo và hạn chế theo dõi" });
        trans.put("uiCategoryTitle", new String[] { "User interface", "Giao diện" });
        trans.put("uiCategoryDesc", new String[] { "Customize user interface", "Tùy giao diện ứng dụng" });
        trans.put("profileCategoryTitle", new String[] { "Profile", "Hồ sơ" });
        trans.put("profileCategoryDesc", new String[] { "Customize profile settings", "Tùy chỉnh cài đặt hồ sơ" });
        trans.put("groupCategoryTitle", new String[] { "Groups", "Nhóm" });
        trans.put("groupCategoryDesc", new String[] { "Customize group features", "Tùy chỉnh các tính năng liên quan đến nhóm" });
        trans.put("advancedFeaturesCategoryTitle", new String[] { "Advanced features", "Tính năng nâng cao" });
        trans.put("advancedFeaturesCategoryDesc", new String[] { "Advanced features and options", "Các tính năng và tuỳ chọn nâng cao" });
        trans.put("backupAndRestoreCategoryTitle", new String[] { "Backup & restore", "Sao lưu & khôi phục" });
        trans.put("backupAndRestoreCategoryDesc", new String[] { "Manage backups and configuration", "Quản lý dữ liệu sao lưu và cấu hình" });
        // Buttons
        trans.put("reloadDexKitCacheBtnTitle", new String[] { "Force reload DexKit cache", "Buộc tải lại bộ nhớ đệm DexKit" });
        trans.put("restartAppBtnTitle", new String[] { "Restart app", "Khởi động lại ứng dụng" });

		// Custom background
		trans.put("backgroundImagesSubCategoryTitle", new String[] { "Background images", "Ảnh nền" });
        trans.put("customBackgroundTitle", new String[] { "Custom background", "Hình nền tuỳ chỉnh" });
        trans.put("addBackgroundImagesTitle", new String[] { "Add background images", "Thêm ảnh nền" });
        trans.put("addBackgroundImagesDesc", new String[] { "Pick one or more images to randomize", "Chọn một hoặc nhiều ảnh để dùng ngẫu nhiên" });
        trans.put("clearBackgroundImagesTitle", new String[] { "Clear custom background images", "Xoá ảnh nền tuỳ chỉnh" });
        trans.put("clearBackgroundImagesDesc", new String[] { "Remove all added images", "Xoá tất cả ảnh đã thêm" });
        
		// Custom call ringtone
		trans.put("callRingtoneSubCategoryTitle", new String[] { "Incoming-call sounds", "Âm thanh cuộc gọi đến" });
        trans.put("customRingtoneTitle", new String[] { "Custom call ringtone", "Nhạc chuông cuộc gọi tuỳ chỉnh" });
        trans.put("customRingtoneDesc", new String[] { "Play a random saved file on each incoming call", "Phát ngẫu nhiên một tệp đã lưu cho mỗi cuộc gọi đến" });
        trans.put("addRingtoneFilesTitle", new String[] { "Add ringtone files", "Thêm tệp nhạc chuông" });
        trans.put("addRingtoneFilesDesc", new String[] { "Pick one or more audio files to randomize", "Chọn một hoặc nhiều tệp âm thanh để dùng ngẫu nhiên" });
        trans.put("clearRingtoneFilesTitle", new String[] { "Clear custom ringtone files", "Xoá tệp nhạc chuông tuỳ chỉnh" });
        trans.put("clearRingtoneFilesDesc", new String[] { "Remove all added audio files", "Xoá tất cả tệp âm thanh đã thêm" });

        //Messages & Conversations
        trans.put("chatHeadSubCategoryTitle", new String[] { "Mini Chat (Chat Head)" });
        trans.put("chatHeadTitle", new String[] { "Replace Android Bubble conversations with Mini Chat", "Thay thế bong bóng hội thoại Android bằng Mini Chat" });
        trans.put("chatHeadDesc", new String[] { "Requires Android 11 or higher", "Yêu cầu Android 11 trở lên" });

        trans.put("disappearingMessagesSubCategoryTitle", new String[] { "Disappearing messages", "Tin nhắn tự xoá" });
        trans.put("ttlOverrideTitle", new String[] { "Override disappearing messages config", "Ghi đè cấu hình tin nhắn tự xoá" });
        trans.put("ttlOverrideDesc", new String[] { "Only works for threads that have disappearing messages enabled", "Chỉ hoạt động với các cuộc trò chuyện đã bật tin nhắn tự xoá" });
        trans.put("ttlTimeTitle", new String[] { "Disappearing message time", "Thời gian tin nhắn tự xoá" });
        trans.put("ttlTimeDesc", new String[] { "Enter value (milliseconds)", "Nhập giá trị (mili giây)" });

        trans.put("antiRecallDeleteSubCategoryTitle", new String[] { "Recalled and deleted messages", "Thu hồi và xoá tin nhắn" });
        trans.put("antiRecallTitle", new String[] { "Anti-Recall", "Chống thu hồi tin nhắn" });
        trans.put("antiDeleteTitle", new String[] { "Anti-Delete", "Chống xoá tin nhắn" });
        trans.put("antiRecallIncludeMeTitle", new String[] { "Include my recalled messages", "Bao gồm tin nhắn tôi đã thu hồi" });
        trans.put("antiDeleteIncludeMyDeletionTitle", new String[] { "Include messages deleted by me", "Bao gồm tin nhắn được tôi xoá" });

        trans.put("effectsAndContentSubCategoryTitle", new String[] { "Effects & content", "Hiệu ứng & nội dung" });
        trans.put("hideFullscreenEffectsTitle", new String[] { "Hide fullscreen effects", "Ẩn hiệu ứng toàn màn hình" });
        trans.put("hideFullscreenEffectsDesc", new String[] { "Hide fullscreen effects when certain messages are received", "Ẩn hiệu ứng toàn màn hình khi nhận được một số tin nhắn nhất định" });
        trans.put("shareHiddenStickerPackTitle", new String[] { "Allow sharing hidden sticker packs", "Cho phép chia sẻ bộ sticker ẩn" });

        trans.put("mediaQualitySubCategoryTitle", new String[] { "Media quality", "Chất lượng nội dung đa phương tiện" });
        trans.put("defaultOriginalQualityTitle", new String[] { "Default to Original quality when selecting images from gallery", "Mặc định chọn chất lượng Original khi chọn ảnh từ thư viện" });
        trans.put("defaultOriginalQualityDesc", new String[] { "Requires the \"Unlock ZCloud\" feature to work", "Yêu cầu tính năng \"Mở khoá ZCloud\" được bật" });
        trans.put("defaultOriginalQualityForPastedImagesTitle", new String[] { "Send pasted images in Original quality", "Gửi ảnh được dán ở chất lượng Original" });
        trans.put("defaultOriginalQualityForPastedImagesDesc", new String[] { "Requires the \"Unlock ZCloud\" feature to work", "Yêu cầu tính năng \"Mở khoá ZCloud\" được bật" });
        trans.put("defaultOriginalQualityShareTitle", new String[] { "Send shared images in Original quality", "Gửi ảnh được chia sẻ ở chất lượng Original" });
        trans.put("defaultOriginalQualityShareDesc", new String[] { "Requires the \"Unlock ZCloud\" feature to work, does not work when forwarding photos", "Yêu cầu tính năng \"Mở khoá ZCloud\" được bật, không hoạt động khi chuyển tiếp ảnh" });
        trans.put("defaultOriginalQualityCameraTitle", new String[] { "Send camera images in Original quality", "Gửi ảnh chụp từ camera ở chất lượng Original" });
        trans.put("defaultOriginalQualityCameraDesc", new String[] { "Requires the \"Unlock ZCloud\" feature to work", "Yêu cầu tính năng \"Mở khoá ZCloud\" được bật" });

        // Privacy
        trans.put("privacyStatusControlSubCategoryTitle", new String[] { "Control activity status and messages", "Kiểm soát trạng thái hoạt động và tin nhắn" });
        trans.put("silentTypingTitle", new String[] { "Hide typing indicators", "Ẩn trạng thái đang nhập" });
        trans.put("blockSendSeenTitle", new String[] { "Hide \"Seen\" status", "Ẩn trạng thái Đã xem" });

        // Ads and tracking
        trans.put("adsSubCategoryTitle", new String[] { "Ads", "Quảng cáo" });
        trans.put("hideMediaBoxTitle", new String[] { "Hide Media Box", "Ẩn Media Box" });
        trans.put("hideBizBoxTitle", new String[] { "Hide Business Box", "Ẩn Business Box" });
        trans.put("hideZInstantAdsTitle", new String[] { "Hide ZInstant Ads", "Ẩn quảng cáo ZInstant" });
        trans.put("hideZInstantAdsDesc", new String[] { "Hide ads in Messages tab", "Ẩn quảng cáo trong tab Tin nhắn" });
        trans.put("hideTimelineAdsTitle", new String[] { "Hide Ads in Timeline", "Ẩn quảng cáo trong Nhật Ký" });
        trans.put("blockAdsEndpointsTitle", new String[] { "Block ads network endpoints", "Chặn yêu cầu mạng quảng cáo" });

        trans.put("logTrackSubCategoryTitle", new String[] { "Logging and tracking", "Ghi nhật ký và theo dõi" });
        trans.put("disableFirebaseLoggingTitle", new String[] { "Disable Firebase logging", "Tắt ghi nhật ký Firebase" });
        trans.put("disableZaloTrackingTitle", new String[] { "Disable Zalo tracking", "Tắt tính năng theo dõi của Zalo" });
        trans.put("blockQosEndpointsTitle", new String[] { "Block QoS network endpoints", "Chặn yêu cầu mạng QoS" });

        // User interface
        trans.put("converMenuSubCategoryTitle", new String[] { "Conversation menu", "Menu trò chuyện" });
        trans.put("extendedGridMenuTitle", new String[] { "Enable extended grid menu", "Kích hoạt chat menu mở rộng" });
        trans.put("extendedGroupRightMenuTitle", new String[] { "Enable extended group right menu", "Kích hoạt menu nhóm mở rộng" });
        trans.put("extendedGroupSettingMenuTitle", new String[] { "Enable extended group settings menu", "Kích hoạt menu cài đặt nhóm mở rộng" });

        trans.put("bottomRowSubCategoryTitle", new String[] { "Bottom row", "Thanh dưới" });
        trans.put("customizeBottomRowTitle", new String[] { "Enable bottom row customization", "Kích hoạt tuỳ chỉnh thanh dưới" });
        trans.put("hideDiscoveryTabTitle", new String[] { "Hide Discovery tab", "Ẩn tab Khám Phá" });
        trans.put("hideNewsfeedTabTitle", new String[] { "Hide Newsfeed tab", "Ẩn tab Tường Nhà" });
        trans.put("showGroupsTabTitle", new String[] { "Show Groups tab", "Hiện tab Nhóm" });
        trans.put("showMoreTabTitle", new String[] { "Show More tab", "Hiện tab Thêm" });
        trans.put("liquidGlassTabBarTitle", new String[] { "TabBar Liquid Glass", "TabBar Liquid Glass" });
        trans.put("liquidGlassTabBarDesc", new String[] { "Floating rounded Liquid Glass TabBar with interactive sliding droplet effect", "Thanh TabBar nổi bo tròn Liquid Glass kèm hiệu ứng giọt kính trượt tương tác" });

        // Profile
        trans.put("profileSubCategoryTitle", new String[] { "Profile", "Hồ sơ" });
        trans.put("restoreProfileMusicTitle", new String[] { "Restore profile music options", "Phục hồi tuỳ chọn nhạc nền hồ sơ" });
        trans.put("restoreProfileMusicDesc", new String[] { "Replace the ZStyle profile music options", "Thay thế tuỳ chọn chọn nhạc nền hồ sơ bằng ZStyle" });

        // Group
        trans.put("groupRoleSubCategoryTitle", new String[] { "Group roles", "Vai trò trong nhóm" });
        trans.put("fakeGroupRoleTitle", new String[] { "Fake my role in groups", "Giả mạo vai trò trong nhóm" });
        trans.put("fakeRoleTitle", new String[] { "Fake role", "Vai trò giả mạo" });

        // Advanced features
        trans.put("paidFeaturesSubCategoryTitle", new String[] { "Paid features", "Chức năng trả phí" });
        trans.put("unlockZCloudTitle", new String[] { "Unlock ZCloud", "Mở khoá ZCloud" });
        trans.put("unlockZCloudDesc", new String[] { "Does not increase My Documents capacity (Server side checks)", "Không tăng dung lượng bộ nhớ My Documents (được kiểm tra trên máy chủ)" });
        trans.put("unlockZStyleTitle", new String[] { "Unlock ZStyle", "Mở khoá ZStyle" });
        trans.put("unlockZStyleDesc", new String[] { "Does not unlock the profile customization feature exclusive to ZStyle (Server side checks)", "Không mở khóa tính năng tùy chỉnh hồ sơ dành riêng cho ZStyle (được kiểm tra trên máy chủ)" });

        trans.put("microGSubCategoryTitle", new String[] { "MicroG" });
        trans.put("useMicroGTitle", new String[] { "Use MicroG instead of Google Mobile Services", "Sử dụng MicroG thay vì Google Mobile Services" });
        trans.put("useMicroGDesc", new String[] { "Always enabled on builds patched by Morphe", "Luôn bật khi vá bằng Morphe" });
        trans.put("microGVariantTitle", new String[] { "MicroG variant", "Biến thể MicroG" });

        // Backup and restore
        trans.put("backupMessagesSubCategoryTitle", new String[] { "Backup messages", "Sao lưu tin nhắn" });
        trans.put("restoreGoogleDriveBackupTitle", new String[] { "Restore Google Drive backup options", "Phục hồi tuỳ chọn sao lưu ảnh bằng Google Drive" });
        trans.put("restoreGoogleDriveBackupDesc", new String[] { "Replace the ZCloud backup options", "Thay thế tuỳ chọn sao lưu bằng ZCloud" });

        trans.put("configBackupRestoreSubCategoryTitle", new String[] { "Configuration backup & restore", "Sao lưu & Khôi phục cấu hình" });
        trans.put("exportConfigFileTitle", new String[] { "Export configuration file", "Xuất tệp cấu hình" });
        trans.put("exportConfigFileDesc", new String[] { "Save to Downloads/ZaloXposed", "Lưu vào thư mục Downloads/ZaloXposed" });
        trans.put("importConfigFileTitle", new String[] { "Import configuration from file", "Nhập cấu hình từ tệp" });
        trans.put("importConfigFileDesc", new String[] { "Choose a JSON file", "Chọn tệp JSON từ bộ nhớ" });
        trans.put("resetConfigTitle", new String[] { "Reset ZaloXposed configuration", "Đặt lại cấu hình ZaloXposed" });

        // Extended settings
        trans.put("extendedSettingsCategoryTitle", new String[] { "Extended Settings", "Cài đặt mở rộng" });
        trans.put("extendedSettingsCategoryDesc", new String[] { "Advanced/hidden settings inside Zalo", "Các cài đặt nâng cao/ẩn bên trong Zalo" });
        trans.put("openSettingViewTitle", new String[] { "Open old Settings view", "Mở giao diện cài đặt cũ" });
        trans.put("openBuildInfoViewTitle", new String[] { "Open Build Info view", "Mở giao diện thông tin phiên bản" });
        trans.put("openBuildInfoViewDesc" , new String[] { "Can be opened by tapping the Zalo version 10 times in Settings > About Zalo", "Có thể mở bằng cách nhấn 10 lần vào phiên bản Zalo trong Cài đặt > Giới thiệu về Zalo" });
        trans.put("openCallLogsViewTitle", new String[] { "Open Call Logs view", "Mở giao diện \"Danh sách log\" cuộc gọi" });


        // Toasts & Messages
        trans.put("exportSuccess", new String[] { "Exported config file to: ", "Đã xuất tệp cấu hình ra: " });
        trans.put("exportSuccessFormat", new String[] { "Exported config file to: %s", "Đã xuất tệp cấu hình ra: %s" });
        trans.put("exportFailed", new String[] { "Export failed (permission denied)!", "Xuất cấu hình thất bại (không có quyền bộ nhớ)!" });
        trans.put("openFilePickerFailed", new String[] { "Cannot find activity to open file picker!", "Không tìm thấy Activity để mở trình chọn file!" });
        trans.put("importSuccess", new String[] { "Configuration imported successfully, restart app to apply.", "Đã nhập cấu hình, khởi động lại app để áp dụng." });
        trans.put("importFailed", new String[] { "Failed to read or parse configuration file!", "Không thể đọc tệp hoặc định dạng JSON không hợp lệ!" });
        trans.put("importError", new String[] { "Error importing: ", "Lỗi khi nhập tệp: " });
        trans.put("importErrorFormatted", new String[] { "Error importing: %s", "Lỗi khi nhập tệp: %s" });

        // Dynamic / headers
        trans.put("moduleSettingsDesc", new String[] { "%s settings", "Cài đặt %s" });
        trans.put("moduleSettingsHeaderTitle", new String[] { "%s Settings", "Cài đặt %s" });

        trans.put("roleAdmin", new String[] { "Admin", "Phó nhóm" });
        trans.put("roleOwner", new String[] { "Owner", "Trưởng nhóm" });
        trans.put("microGMissingTitle", new String[] { "MicroG client is not installed", "Ứng dụng khách MicroG chưa được cài đặt" });
        trans.put("microGMissingDesc", new String[] { "A MicroG client is required, please download and install it from the link below, or disable the \"Use MicroG\" option in ZaloXposed settings if you are using rooted version.", "Cần có ứng dụng khách MicroG, vui lòng tải xuống và cài đặt từ liên kết bên dưới, hoặc tắt tùy chọn \"Sử dụng MicroG\" trong cài đặt ZaloXposed nếu bạn đang sử dụng phiên bản root." });
        trans.put("cancel", new String[] { "Cancel", "Hủy" });
        trans.put("gotoDownload", new String[] { "Go to download page", "Đi tới trang tải xuống" });
        trans.put("amoledTheme", new String[] { "AMOLED Dark theme", "Chủ đề tối AMOLED" });
        trans.put("bgImagesAdded", new String[] { "Added %d image(s), skipped %d duplicate(s).", "Đã thêm %d ảnh, bỏ qua %d ảnh trùng." });
        trans.put("bgImagesCleared", new String[] { "Cleared %d image(s)", "Đã xoá %d ảnh" });
        trans.put("bgImagesFailed", new String[] { "No valid image selected", "Không có ảnh hợp lệ nào được chọn" });
        trans.put("bgImageCount", new String[] { "Saved %d background images", "Đã lưu %d ảnh nền" });
        trans.put("bgImageCountEmpty", new String[] { "Saved 0 background images", "Đã lưu 0 ảnh nền" });
        trans.put("ringtoneFilesAdded", new String[] { "Added %d ringtone file(s), skipped %d duplicate(s).", "Đã thêm %d tệp nhạc chuông, bỏ qua %d tệp trùng." });
        trans.put("ringtoneFilesCleared", new String[] { "Cleared %d ringtone file(s)", "Đã xoá %d tệp nhạc chuông" });
        trans.put("ringtoneFilesFailed", new String[] { "No valid audio file selected", "Không có tệp âm thanh hợp lệ nào được chọn" });
        trans.put("ringtoneFileCount", new String[] { "Saved %d ringtone files", "Đã lưu %d tệp nhạc chuông" });
        trans.put("ringtoneFileCountEmpty", new String[] { "Saved 0 ringtone files", "Đã lưu 0 tệp nhạc chuông" });
    }

    public static String tr(String key)
    {
        if (TextUtils.isEmpty(key))
            return "";
        if (key.contains(" "))
            return key;
        String[] values = trans.get(key);
        if (values == null || values.length == 0)
        {
            Logger.w("Missing string values for key " + key);
            return key;
        }
        if (values.length == 1)
        {
            Logger.i("Using default value for key " + key);
            return values[0];
        }
        return values[Utils.IsEnglish() ? 0 : 1];
    }

    public static String tr(String key, Object... args)
    {
        String str = tr(key);
        if (args == null || args.length == 0)
            return str;
        try
        {
            return String.format(str, args);
        }
        catch (Exception ignored) { }
        return str;
    }
}